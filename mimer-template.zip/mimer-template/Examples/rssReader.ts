function async main() {
  return "Test";
}

console.log(main());

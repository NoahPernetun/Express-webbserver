# Mimer Template

This is a collection of empty project that could be use as a base for 
other project. The chosses made in here is opinited, but it would be 
easy to adopt to youre taste.

## Configuration

###
- **year**: When created.

### For each project
- **gitPath**: The domain and path to git arcive.
- **issuesUrl**:  URL to the issues handler.
- **projectName**: Name of projekt.

### For a developer
- **author**: Your name.
- **myUrl**: URL to my homepage.

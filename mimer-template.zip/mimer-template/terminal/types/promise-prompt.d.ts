// promise-prompt.d.ts
declare module 'promise-prompt';

#!/usr/bin/env node
import prompt from 'promise-prompt';
import colors from 'colors';

async function main() {
  const name = prompt("What is your name? ");
  name.then((name:string)=> {
    console.log("Hello "+colors.bold.red(name)+"!")
 })
}

main();

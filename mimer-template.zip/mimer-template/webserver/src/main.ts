#!/usr/bin/node
import express from 'express';

async function main() {
const app = express();

app.use((req, res, next) => {
    const datetime = new Date();
    const hours = datetime.getHours();
    const minutes = datetime.getMinutes();
    const seconds = datetime.getSeconds();
    let msg = console.log(
    "["+((Number(hours)>9)?hours:("0"+hours))+
    ":"+ ((Number(minutes))>9?minutes:("0"+minutes))+
    ":"+((Number(seconds))>9?seconds :("0"+seconds))+"]"+
    " #" +req.originalUrl+
    " @" +req.ip
    );
    next();
});

app.use(express.urlencoded());

app.get("/", function(req, res) {
   res.send("Hello World!");
});

const port = 8080;

app.listen(port, ()=> {
   console.log("You can find this server on: http://localhost:"+port);
  });
}

main();
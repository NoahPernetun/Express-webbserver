# NAME



## Install


```
$ npm install 
```

## Usage


```

```

## API



### Functions



### Class



## License

GPL, see LICENSE file

## Contribute

Please feel free to open an issue or submit a pull request.

## Changelog

 * **0.0.1** *{{year}}-??-??* First version published


## Author

**©AUTHOR YEAR [MY_URL](MY_URL)**
